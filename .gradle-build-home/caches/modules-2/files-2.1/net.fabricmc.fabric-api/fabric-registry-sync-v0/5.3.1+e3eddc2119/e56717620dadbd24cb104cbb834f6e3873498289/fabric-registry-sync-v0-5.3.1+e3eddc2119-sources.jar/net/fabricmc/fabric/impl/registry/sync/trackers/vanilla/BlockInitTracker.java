/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.registry.sync.trackers.vanilla;

import java.util.List;
import net.fabricmc.fabric.api.event.registry.RegistryEntryAddedCallback;
import net.fabricmc.fabric.mixin.registry.sync.DebugChunkGeneratorAccessor;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_7923;

public final class BlockInitTracker implements RegistryEntryAddedCallback<class_2248> {
	private final class_2378<class_2248> registry;

	private BlockInitTracker(class_2378<class_2248> registry) {
		this.registry = registry;
	}

	public static void register(class_2378<class_2248> registry) {
		BlockInitTracker tracker = new BlockInitTracker(registry);
		RegistryEntryAddedCallback.event(registry).register(tracker);
	}

	@Override
	public void onEntryAdded(int rawId, class_2960 id, class_2248 object) {
		// if false, getLootTableKey() will generate an invalid loot table key
		assert id.equals(registry.method_10221(object));

		object.method_26162();
	}

	public static void postFreeze() {
		final List<class_2680> blockStateList = class_7923.field_41175.method_10220()
				.flatMap((block) -> block.method_9595().method_11662().stream())
				.toList();

		final int xLength = class_3532.method_15386(class_3532.method_15355(blockStateList.size()));
		final int zLength = class_3532.method_15386(blockStateList.size() / (float) xLength);

		DebugChunkGeneratorAccessor.setBLOCK_STATES(blockStateList);
		DebugChunkGeneratorAccessor.setX_SIDE_LENGTH(xLength);
		DebugChunkGeneratorAccessor.setZ_SIDE_LENGTH(zLength);
	}
}
